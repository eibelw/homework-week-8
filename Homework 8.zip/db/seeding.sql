INSERT INTO actor (actor_id, first_name, last_name, last_update)
VALUES (201, 'Abel', 'Winson', '2023-09-30 13:52:34.09');

INSERT INTO actor (actor_id, first_name, last_name, last_update)
VALUES (202, 'Jamila', 'Lopi', '2023-09-30 13:52:34.09');

INSERT INTO actor (actor_id, first_name, last_name, last_update)
VALUES (203, 'Wedus', 'Zeus', '2023-09-30 13:52:34.09');

INSERT INTO actor (actor_id, first_name, last_name, last_update)
VALUES (204, 'Filare', 'Lopez', '2023-09-30 13:52:34.09');

INSERT INTO actor (actor_id, first_name, last_name, last_update)
VALUES (205, 'Roman', 'Miyap', '2023-09-30 13:52:34.09');
