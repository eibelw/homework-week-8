/* Replace with your SQL commands */
ALTER TABLE actor
ADD COLUMN age int;